# PRE-INSTALLATION

Before you install `jami-commander` with `pip install jami-commander`
you *must* have followed these prerequisites steps!

- You must have Python 3.12+ installed. 3.11 might work.
- Run `python -V` to get your Python version number.
- Read the README.md file to see how to install and run Jami daemon `jamid`. 
